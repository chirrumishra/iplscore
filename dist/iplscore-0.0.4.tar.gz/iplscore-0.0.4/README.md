#IPLSCORE

This is a library which is made for fun and getting ipl score while working 

Developed by Chiranjeev Mishra

##Example of How to use it 


'''python
import iplscore

iplscore.match()
'''
